import Hero from "@/components/Hero";

export default function HomePage() {
  return (
    <main className="min-h-screen" role="main">
      <Hero />
    </main>
  );
}
